from serial import Serial
import pynmea2
import time
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs
import json

# Global variable to store the latest GPS data
gps_data = {
    'satellites': 0,
    'quality': 0,
    'latitude': 0,
    'longitude': 0,
    'timestamp': ''
}

# Thread lock for thread-safe updates
data_lock = threading.Lock()

class GPSDataHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            # Serve HTML page
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            html = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <title>GPS Data Monitor</title>
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 20px; }}
                    .data-container {{ 
                        border: 1px solid #ccc; 
                        padding: 20px;
                        border-radius: 5px;
                        max-width: 600px;
                    }}
                    .update-time {{
                        color: #666;
                        font-size: 0.8em;
                    }}
                </style>
                <script>
                    function updateData() {{
                        fetch('/data')
                            .then(response => response.json())
                            .then(data => {{
                                document.getElementById('satellites').textContent = data.satellites;
                                document.getElementById('quality').textContent = data.quality;
                                document.getElementById('latitude').textContent = data.latitude;
                                document.getElementById('longitude').textContent = data.longitude;
                                document.getElementById('timestamp').textContent = data.timestamp;
                            }});
                    }}
                    
                    // Update every second
                    setInterval(updateData, 1000);
                    // Initial update
                    updateData();
                </script>
            </head>
            <body>
                <h1>GPS Data Monitor</h1>
                <div class="data-container">
                    <h3>Real-time GPS Data</h3>
                    <p>Jumlah Satelit: <span id="satellites">-</span></p>
                    <p>Kualitas Fix: <span id="quality">-</span></p>
                    <p>Latitude: <span id="latitude">-</span></p>
                    <p>Longitude: <span id="longitude">-</span></p>
                    <p class="update-time">Last Update: <span id="timestamp">-</span></p>
                </div>
            </body>
            </html>
            """
            self.wfile.write(html.encode())
            
        elif self.path == '/data':
            # Serve JSON data
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            with data_lock:
                self.wfile.write(json.dumps(gps_data).encode())

def run_web_server(port=8080):
    server_address = ('', port)
    httpd = HTTPServer(server_address, GPSDataHandler)
    print(f"Server berjalan di port {port}")
    httpd.serve_forever()

def read_gps(serial_port):
    while True:
        try:
            if serial_port.in_waiting > 0:
                line = serial_port.readline().decode('utf-8')
                print(f"Raw data: {line}")  # Debug print
                
                if line.startswith('$GPGGA'):
                    msg = pynmea2.parse(line)
                    with data_lock:
                        gps_data['satellites'] = msg.num_sats
                        gps_data['quality'] = msg.gps_qual
                        gps_data['latitude'] = msg.latitude
                        gps_data['longitude'] = msg.longitude
                        gps_data['timestamp'] = time.strftime('%Y-%m-%d %H:%M:%S')
                    
                    print(f"Data updated: {gps_data}")  # Debug print
                    
        except Exception as e:
            print(f"Error membaca GPS: {e}")
            time.sleep(1)

if __name__ == '__main__':
    try:
        # Inisialisasi port serial
        ser = Serial(
            port='/dev/ttyTHS1',
            baudrate=9600,
            timeout=1
        )
        
        # Mulai thread web server
        web_thread = threading.Thread(target=run_web_server, daemon=True)
        web_thread.start()
        
        # Mulai membaca GPS di thread utama
        read_gps(ser)
        
    except Exception as e:
        print(f"Error: {e}")
    except KeyboardInterrupt:
        if 'ser' in locals():
            ser.close()
        print("\nProgram dihentikan")
