#!/usr/bin/env python

import os
import rospy
import rospkg
from rqt_gui_py.plugin import Plugin
from python_qt_binding import loadUi
from python_qt_binding.QtWidgets import QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QGridLayout
from python_qt_binding.QtCore import Qt, QTimer
from python_qt_binding.QtGui import QImage, QPixmap
from sensor_msgs.msg import Image, NavSatFix
from std_srvs.srv import SetBool
import numpy as np
import cv2


class GPSCameraPlugin(Plugin):
    def __init__(self, context):
        super(GPSCameraPlugin, self).__init__(context)
        self.setObjectName('GPSCameraPlugin')

        # Create QWidget
        self._widget = QWidget()
        self._widget.setObjectName('GPSCameraPluginUi')
        
        # Layout setup
        layout = QVBoxLayout()
        
        # Camera grid
        camera_grid = QGridLayout()
        self.camera_labels = {}
        for i in range(3):
            self.camera_labels[i] = QLabel()
            self.camera_labels[i].setMinimumSize(320, 240)
            self.camera_labels[i].setAlignment(Qt.AlignCenter)
            # Mengubah f-string menjadi format string Python 2.7
            self.camera_labels[i].setText("Camera {}".format(i))
            camera_grid.addWidget(self.camera_labels[i], 0, i)
        layout.addLayout(camera_grid)
        
        # GPS Display
        self.gps_label = QLabel("GPS: Waiting for data...")
        layout.addWidget(self.gps_label)
        
        # Control buttons
        button_layout = QHBoxLayout()
        self.record_button = QPushButton("Start Recording")
        self.record_button.clicked.connect(self.toggle_recording)
        button_layout.addWidget(self.record_button)
        layout.addLayout(button_layout)
        
        self._widget.setLayout(layout)
        
        # Add widget to the user interface
        context.add_widget(self._widget)
        
        # Initialize ROS subscribers
        self.camera_subs = []
        for i in range(3):
            # Mengubah f-string menjadi format string Python 2.7
            sub = rospy.Subscriber('/camera{}/image_raw'.format(i), Image, 
                                 lambda msg, cam_id=i: self.camera_callback(msg, cam_id))
            self.camera_subs.append(sub)
            
        self.gps_sub = rospy.Subscriber('/gps/fix', NavSatFix, self.gps_callback)
        
        # Recording state
        self.is_recording = False


    def camera_callback(self, msg, camera_id):
        """Handle camera image"""
        try:
            # Convert ROS image to OpenCV format
            image = np.frombuffer(msg.data, dtype=np.uint8)
            image = image.reshape(msg.height, msg.width, -1)

            # Konversi BGR ke RGB
            image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)  # Tambahkan baris ini

            # Convert to QImage
            height, width, channel = image.shape
            bytes_per_line = 3 * width
            q_img = QImage(image.data, width, height, bytes_per_line, QImage.Format_RGB888)

            # Scale and display
            pixmap = QPixmap.fromImage(q_img)
            scaled_pixmap = pixmap.scaled(320, 240, Qt.KeepAspectRatio)
            self.camera_labels[camera_id].setPixmap(scaled_pixmap)

        except Exception as e:
            rospy.logerr("Error processing camera {} image: {}".format(camera_id, str(e)))

    def gps_callback(self, msg):
        """Handle GPS data"""
        try:
            # Mengubah f-string menjadi format string Python 2.7
            gps_text = "GPS: Lat: {:.6f}, Lon: {:.6f}".format(msg.latitude, msg.longitude)
            self.gps_label.setText(gps_text)
        except Exception as e:
            # Mengubah f-string menjadi format string Python 2.7
            rospy.logerr("Error processing GPS data: {}".format(str(e)))

    def toggle_recording(self):
        """Toggle recording state"""
        try:
            rospy.wait_for_service('/recorder/set_recording', timeout=1.0)
            record_srv = rospy.ServiceProxy('/recorder/set_recording', SetBool)
            
            self.is_recording = not self.is_recording
            response = record_srv(self.is_recording)
            
            if response.success:
                self.record_button.setText("Stop Recording" if self.is_recording else "Start Recording")
                rospy.loginfo(response.message)
            else:
                # Mengubah f-string menjadi format string Python 2.7
                rospy.logerr("Failed to toggle recording: {}".format(response.message))
                
        except Exception as e:
            # Mengubah f-string menjadi format string Python 2.7
            rospy.logerr("Error toggling recording: {}".format(str(e)))

    def shutdown_plugin(self):
        """Clean up subscribers when plugin is shut down"""
        for sub in self.camera_subs:
            sub.unregister()
        self.gps_sub.unregister()
