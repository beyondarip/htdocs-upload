#!/usr/bin/env python3

import rospy
import cv2
import numpy as np
from sensor_msgs.msg import Image
import threading

class RealSenseOpenCVNode:
    def __init__(self):
        rospy.init_node('camera_node', anonymous=True)
        
        self.camera_id = rospy.get_param('~camera_id', 0)
        self.frame_rate = rospy.get_param('~frame_rate', 30)
        self.width = rospy.get_param('~width', 640)
        self.height = rospy.get_param('~height', 480)
        
        self.image_pub = rospy.Publisher(
            f'/camera{self.camera_id}/image_raw',
            Image,
            queue_size=10
        )
        
        self.cap = None
        self.running = False
        self.lock = threading.Lock()
        
    def numpy_to_image_msg(self, frame):
        """Convert numpy array ke ROS image message"""
        # Convert BGR ke RGB
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        msg = Image()
        msg.height = rgb_frame.shape[0]
        msg.width = rgb_frame.shape[1]
        msg.encoding = 'rgb8'
        msg.is_bigendian = False
        msg.step = rgb_frame.shape[1] * 3
        msg.data = rgb_frame.tobytes()
        return msg

    def connect_camera(self):
        try:
            # Gunakan GStreamer pipeline untuk RealSense
            gst_str = (
                f"v4l2src device=/dev/video{self.camera_id} ! "
                f"video/x-raw,width={self.width},height={self.height},"
                f"framerate={self.frame_rate}/1 ! "
                "videoconvert ! "
                "video/x-raw,format=BGR ! "
                "appsink max-buffers=1 drop=true"
            )
            
            self.cap = cv2.VideoCapture(gst_str, cv2.CAP_GSTREAMER)
            
            if not self.cap.isOpened():
                # Fallback ke direct capture jika GStreamer gagal
                self.cap = cv2.VideoCapture(self.camera_id)
                self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
                self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
                self.cap.set(cv2.CAP_PROP_FPS, self.frame_rate)
                # Set buffer size kecil untuk mengurangi latency
                self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                
                # Set format pixel
                self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M','J','P','G'))
            
            if not self.cap.isOpened():
                raise Exception(f"Could not open camera {self.camera_id}")
                
            rospy.loginfo(f"Camera {self.camera_id} connected successfully")
            return True
            
        except Exception as e:
            rospy.logerr(f"Failed to connect to camera {self.camera_id}: {str(e)}")
            return False
            
    def capture_and_publish(self):
        while not rospy.is_shutdown() and self.running:
            try:
                with self.lock:
                    if self.cap is None or not self.cap.isOpened():
                        if not self.connect_camera():
                            rospy.sleep(1)
                            continue
                            
                    ret, frame = self.cap.read()
                    
                    if not ret or frame is None:
                        rospy.logwarn(f"Failed to capture frame from camera {self.camera_id}")
                        # Coba reconnect
                        self.cap.release()
                        self.cap = None
                        continue
                    
                    # Tambahan preprocessing untuk menangani masalah warna
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                    
                    # Convert dan publish
                    img_msg = self.numpy_to_image_msg(frame)
                    img_msg.header.stamp = rospy.Time.now()
                    img_msg.header.frame_id = f"camera_{self.camera_id}"
                    self.image_pub.publish(img_msg)
                        
            except Exception as e:
                rospy.logerr(f"Error in capture loop: {str(e)}")
                rospy.sleep(1)
                
            rate = rospy.Rate(self.frame_rate)
            rate.sleep()
            
    def start(self):
        try:
            if self.connect_camera():
                self.running = True
                self.capture_thread = threading.Thread(target=self.capture_and_publish)
                self.capture_thread.daemon = True
                self.capture_thread.start()
                
                rospy.loginfo(f"Camera node {self.camera_id} started successfully")
                rospy.spin()
            else:
                rospy.logerr(f"Failed to start camera node {self.camera_id}")
                
        except Exception as e:
            rospy.logerr(f"Error starting camera node: {str(e)}")
            
    def stop(self):
        self.running = False
        if hasattr(self, 'capture_thread'):
            self.capture_thread.join()
        if self.cap:
            self.cap.release()
        rospy.loginfo(f"Camera node {self.camera_id} stopped")

if __name__ == '__main__':
    try:
        camera_node = RealSenseOpenCVNode()
        camera_node.start()
    except rospy.ROSInterruptException:
        pass
    finally:
        if 'camera_node' in locals():
            camera_node.stop()
